/**
 * USE CASE: Multi-Chain Treasury Management
 *
 * ===========================
 * BUSINESS SCENARIO
 * ===========================
 *
 * You're managing a company's treasury with USDC spread across multiple blockchains.
 * You need to consolidate funds periodically to your main treasury wallet for
 * accounting, reporting, or to meet payment obligations.
 *
 * PROBLEM:
 * - Funds scattered across Ethereum, Base, Arbitrum, Polygon, etc.
 * - Manual consolidation is time-consuming and error-prone
 * - Need to minimize gas fees during consolidation
 * - Want to maintain minimum balances on each chain for operations
 *
 * SOLUTION WITH APP KIT:
 * 1. Automatically check balances across all chains
 * 2. Calculate which chains have excess funds
 * 3. Bridge excess funds to main treasury chain
 * 4. Maintain minimum operational balances
 * 5. Schedule regular consolidation runs
 *
 * ===========================
 * BUSINESS LOGIC FLOW
 * ===========================
 *
 * Step 1: Check balances across chains
 *   - Query USDC balance on each chain
 *   - Compare against target/minimum balances
 *   - Identify chains with excess funds
 *
 * Step 2: Calculate consolidation needs
 *   - Excess = Current Balance - Target Balance
 *   - Only consolidate if excess > threshold (e.g., $100)
 *   - Prioritize by excess amount
 *
 * Step 3: Execute consolidation
 *   - Bridge excess from each chain to main treasury
 *   - Use SLOW mode to save on fees (not time-sensitive)
 *   - Track all transactions for accounting
 *
 * Step 4: Verify and report
 *   - Confirm all bridges completed
 *   - Update balance records
 *   - Generate consolidation report
 *
 * ===========================
 * BENEFITS
 * ===========================
 *
 * Cost Savings:
 * ✓ Automated process saves manual labor
 * ✓ Use SLOW bridge mode (free) for consolidation
 * ✓ Only consolidate when threshold met (avoid tiny transactions)
 *
 * Financial Control:
 * ✓ Centralized view of treasury
 * ✓ Predictable cash position
 * ✓ Easier accounting and reporting
 * ✓ Better liquidity management
 *
 * Operational Efficiency:
 * ✓ Scheduled automation (daily, weekly)
 * ✓ Maintain operational balances
 * ✓ Reduce manual errors
 * ✓ Audit trail of all movements
 */

import 'dotenv/config';
import { StablecoinKit } from '@circle-fin/stablecoin-kit';
import { createViemAdapterFromPrivateKey } from '@circle-fin/adapter-viem-v2';
import { inspect } from 'util';

// ===========================
// TYPE DEFINITIONS
// ===========================

interface ChainBalance {
  chain: string;                    // Chain name (e.g., "Base")
  currentBalance: number;           // Current USDC balance
  targetBalance: number;            // Desired balance to maintain
  minimumBalance: number;           // Never go below this
}

interface ConsolidationConfig {
  mainTreasuryChain: string;        // Where to consolidate funds to
  mainTreasuryAddress: string;      // Treasury wallet address
  consolidationThreshold: number;   // Only consolidate if excess > this amount
  useSlowMode: boolean;             // Use SLOW (free) or FAST bridge
}

interface ConsolidationOperation {
  fromChain: string;
  toChain: string;
  amount: string;
  reason: string;
  status: 'pending' | 'completed' | 'failed';
  txHashes: string[];
  explorerUrls: string[];
  error?: string;
}

interface ConsolidationReport {
  timestamp: string;
  totalConsolidated: number;
  operations: ConsolidationOperation[];
  finalBalances: Record<string, number>;
  costSavings: string;
}

// ===========================
// HELPER FUNCTIONS
// ===========================

/**
 * Mock function to get USDC balance on a chain
 * In production, you would query the blockchain directly
 */
async function getUSDCBalance(chain: string, adapter: any): Promise<number> {
  // TODO: Implement actual balance checking
  // Example using viem:
  // const balance = await adapter.getBalance({
  //   chain,
  //   token: 'USDC'
  // });
  // return parseFloat(ethers.formatUnits(balance, 6));

  // Mock data for demonstration
  const mockBalances: Record<string, number> = {
    'Base': 15000,
    'Arbitrum': 12500,
    'Polygon': 8000,
    'Optimism': 5500,
    'Ethereum': 25000  // Main treasury
  };

  return mockBalances[chain] || 0;
}

// ===========================
// MAIN CONSOLIDATION LOGIC
// ===========================

async function consolidateTreasury(
  chainBalances: ChainBalance[],
  config: ConsolidationConfig
): Promise<ConsolidationReport> {
  const kit = new StablecoinKit();
  const adapter = createViemAdapterFromPrivateKey({
    privateKey: process.env.PRIVATE_KEY as string,
  });

  console.log('\n=== Starting Treasury Consolidation ===\n');
  console.log('Configuration:');
  console.log(`  Main Treasury: ${config.mainTreasuryChain}`);
  console.log(`  Treasury Address: ${config.mainTreasuryAddress}`);
  console.log(`  Consolidation Threshold: $${config.consolidationThreshold}`);
  console.log(`  Bridge Mode: ${config.useSlowMode ? 'SLOW (Free)' : 'FAST'}`);

  const operations: ConsolidationOperation[] = [];
  let totalConsolidated = 0;

  console.log('\n--- Analyzing Balances ---\n');

  // Analyze each chain
  for (const chainInfo of chainBalances) {
    console.log(`${chainInfo.chain}:`);
    console.log(`  Current: $${chainInfo.currentBalance.toFixed(2)}`);
    console.log(`  Target: $${chainInfo.targetBalance.toFixed(2)}`);

    // Skip the main treasury chain
    if (chainInfo.chain === config.mainTreasuryChain) {
      console.log(`  → Skipped (main treasury)\n`);
      continue;
    }

    // Calculate excess
    const excess = chainInfo.currentBalance - chainInfo.targetBalance;

    if (excess > config.consolidationThreshold) {
      // Ensure we don't go below minimum
      const amountToConsolidate = Math.min(
        excess,
        chainInfo.currentBalance - chainInfo.minimumBalance
      );

      if (amountToConsolidate > config.consolidationThreshold) {
        console.log(`  → Consolidating $${amountToConsolidate.toFixed(2)}\n`);

        operations.push({
          fromChain: chainInfo.chain,
          toChain: config.mainTreasuryChain,
          amount: amountToConsolidate.toFixed(2),
          reason: `Excess of $${excess.toFixed(2)} above target`,
          status: 'pending',
          txHashes: [],
          explorerUrls: []
        });

        totalConsolidated += amountToConsolidate;
      } else {
        console.log(`  → Excess too small after minimum balance protection\n`);
      }
    } else if (excess > 0) {
      console.log(`  → Excess below threshold ($${excess.toFixed(2)})\n`);
    } else {
      console.log(`  → Below target (no consolidation needed)\n`);
    }
  }

  // Execute consolidations
  console.log('--- Executing Consolidations ---\n');

  for (const operation of operations) {
    try {
      console.log(`Consolidating from ${operation.fromChain}:`);
      console.log(`  Amount: $${operation.amount}`);
      console.log(`  Destination: ${operation.toChain}`);

      const result = await kit.bridge({
        from: { adapter, chain: operation.fromChain },
        to: {
          adapter,
          chain: operation.toChain,
          recipientAddress: config.mainTreasuryAddress
        },
        amount: operation.amount,
        config: {
          transferSpeed: config.useSlowMode ? 'SLOW' : 'FAST'
        }
      });

      operation.status = 'completed';
      operation.txHashes = result.steps.map(s => s.txHash);
      operation.explorerUrls = result.steps.map(s => s.explorerUrl);

      console.log(`  ✓ Completed (${result.state})`);
      result.steps.forEach((step, i) => {
        console.log(`    Step ${i + 1}: ${step.action}`);
        console.log(`      TX: ${step.txHash}`);
      });
      console.log('');

    } catch (error: any) {
      operation.status = 'failed';
      operation.error = error.message;

      console.error(`  ✗ Failed: ${error.message}\n`);
    }
  }

  // Get final balances
  console.log('--- Final Balances ---\n');
  const finalBalances: Record<string, number> = {};

  for (const chainInfo of chainBalances) {
    const balance = await getUSDCBalance(chainInfo.chain, adapter);
    finalBalances[chainInfo.chain] = balance;
    console.log(`${chainInfo.chain}: $${balance.toFixed(2)}`);
  }

  // Generate report
  const report: ConsolidationReport = {
    timestamp: new Date().toISOString(),
    totalConsolidated,
    operations,
    finalBalances,
    costSavings: config.useSlowMode
      ? `~$${(operations.length * 0.01).toFixed(2)} (used SLOW mode)`
      : 'N/A (used FAST mode)'
  };

  console.log('\n=== Consolidation Complete ===\n');
  console.log(`Total Consolidated: $${totalConsolidated.toFixed(2)}`);
  console.log(`Successful Operations: ${operations.filter(o => o.status === 'completed').length}/${operations.length}`);
  console.log(`Cost Savings: ${report.costSavings}`);

  return report;
}

// ===========================
// SCHEDULED CONSOLIDATION
// ===========================

/**
 * Run consolidation on a schedule (e.g., daily)
 * In production, use a cron job or task scheduler
 */
async function scheduledConsolidation() {
  console.log('=== Scheduled Treasury Consolidation ===\n');
  console.log(`Run at: ${new Date().toISOString()}\n`);

  // Define your chain balances and targets
  const chainBalances: ChainBalance[] = [
    {
      chain: 'Base',
      currentBalance: 15000,
      targetBalance: 10000,
      minimumBalance: 5000
    },
    {
      chain: 'Arbitrum',
      currentBalance: 12500,
      targetBalance: 10000,
      minimumBalance: 5000
    },
    {
      chain: 'Polygon',
      currentBalance: 8000,
      targetBalance: 10000,
      minimumBalance: 5000
    },
    {
      chain: 'Optimism',
      currentBalance: 5500,
      targetBalance: 10000,
      minimumBalance: 5000
    },
    {
      chain: 'Ethereum',
      currentBalance: 25000,  // Main treasury
      targetBalance: 50000,   // We want to grow this
      minimumBalance: 20000
    }
  ];

  const config: ConsolidationConfig = {
    mainTreasuryChain: 'Ethereum',
    mainTreasuryAddress: process.env.TREASURY_ADDRESS || '0xYourTreasuryAddress',
    consolidationThreshold: 1000,  // Only if excess > $1000
    useSlowMode: true              // Save on fees
  };

  try {
    const report = await consolidateTreasury(chainBalances, config);

    // Save report to database or file
    console.log('\n--- Consolidation Report ---');
    console.log(JSON.stringify(report, null, 2));

    // Send notification email/slack
    // await sendNotification(report);

  } catch (error) {
    console.error('Consolidation failed:', error);
    // Send alert
    // await sendAlert(error);
  }
}

// ===========================
// ADVANCED: REBALANCING
// ===========================

/**
 * Not just consolidation - also distribute funds to chains that are low
 */
async function rebalanceTreasury(
  chainBalances: ChainBalance[],
  config: ConsolidationConfig
) {
  console.log('\n=== Advanced Treasury Rebalancing ===\n');

  const operations: ConsolidationOperation[] = [];

  for (const chainInfo of chainBalances) {
    const difference = chainInfo.currentBalance - chainInfo.targetBalance;
    const absDifference = Math.abs(difference);

    if (absDifference > config.consolidationThreshold) {
      if (difference > 0) {
        // Chain has excess - consolidate to main
        console.log(`${chainInfo.chain}: Excess of $${difference.toFixed(2)}`);
        console.log(`  → Move to ${config.mainTreasuryChain}`);

        operations.push({
          fromChain: chainInfo.chain,
          toChain: config.mainTreasuryChain,
          amount: difference.toFixed(2),
          reason: 'Excess above target',
          status: 'pending',
          txHashes: [],
          explorerUrls: []
        });

      } else {
        // Chain has deficit - send from main
        const needed = absDifference;
        console.log(`${chainInfo.chain}: Deficit of $${needed.toFixed(2)}`);
        console.log(`  ← Receive from ${config.mainTreasuryChain}`);

        operations.push({
          fromChain: config.mainTreasuryChain,
          toChain: chainInfo.chain,
          amount: needed.toFixed(2),
          reason: 'Below target balance',
          status: 'pending',
          txHashes: [],
          explorerUrls: []
        });
      }
    }
  }

  console.log(`\nPlanned operations: ${operations.length}`);
  console.log('To execute this rebalancing, uncomment the execution code below.\n');

  // Execute operations
  // const kit = new StablecoinKit();
  // const adapter = createViemAdapterFromPrivateKey({...});
  // for (const op of operations) { await kit.bridge({...}); }

  return operations;
}

// ===========================
// EXAMPLE USAGE
// ===========================

async function runExample() {
  console.log('=== Treasury Management Examples ===\n');

  // Check environment variables
  if (!process.env.PRIVATE_KEY) {
    console.log('⚠️  Missing PRIVATE_KEY in .env file\n');
    console.log('Set PRIVATE_KEY to run this example.\n');
    return;
  }

  console.log('Example 1: One-time Consolidation\n');
  console.log('This example consolidates excess USDC from multiple chains');
  console.log('to your main treasury on Ethereum.\n');
  console.log('Chains with excess funds:');
  console.log('  - Base: $15,000 (target: $10,000) → Consolidate $5,000');
  console.log('  - Arbitrum: $12,500 (target: $10,000) → Consolidate $2,500');
  console.log('\nTotal to consolidate: $7,500\n');

  // Uncomment to run:
  // await scheduledConsolidation();

  console.log('---\n');
  console.log('Example 2: Scheduled Daily Consolidation\n');
  console.log('In production, run this with a cron job:');
  console.log('  0 2 * * * node dist/treasury-consolidation.js\n');
  console.log('This runs at 2 AM daily to consolidate funds automatically.\n');

  console.log('---\n');
  console.log('Example 3: Advanced Rebalancing\n');
  console.log('Not just consolidation - also distribute to low chains:');
  console.log('  - Polygon: $8,000 (target: $10,000) → Send $2,000 from main');
  console.log('  - Base: $15,000 (target: $10,000) → Take $5,000 to main');
  console.log('\nThis maintains optimal liquidity across all chains.\n');

  // Show the rebalancing plan
  const chainBalances: ChainBalance[] = [
    { chain: 'Base', currentBalance: 15000, targetBalance: 10000, minimumBalance: 5000 },
    { chain: 'Polygon', currentBalance: 8000, targetBalance: 10000, minimumBalance: 5000 },
    { chain: 'Ethereum', currentBalance: 25000, targetBalance: 50000, minimumBalance: 20000 }
  ];

  const config: ConsolidationConfig = {
    mainTreasuryChain: 'Ethereum',
    mainTreasuryAddress: '0xTreasuryAddress',
    consolidationThreshold: 1000,
    useSlowMode: true
  };

  await rebalanceTreasury(chainBalances, config);

  console.log('\nTo execute these examples:');
  console.log('1. Set up your .env with PRIVATE_KEY and TREASURY_ADDRESS');
  console.log('2. Update chainBalances with your actual balances');
  console.log('3. Uncomment the execution lines');
  console.log('4. Run: npm run dev examples/app-kit/02-treasury-management.ts');
}

// ===========================
// INTEGRATION TIPS
// ===========================

/*
PRODUCTION DEPLOYMENT CHECKLIST:

1. Set up automated balance checking:
   - Query balances from each chain
   - Store in database for tracking
   - Alert if any chain goes below minimum

2. Schedule regular consolidation:
   - Use cron job (Linux) or Task Scheduler (Windows)
   - Run during low-gas periods (weekends/nights)
   - Consider gas prices before execution

3. Implement monitoring:
   - Log all operations to database
   - Track success/failure rates
   - Monitor accumulated savings
   - Set up alerts for failures

4. Security considerations:
   - Use separate wallet for consolidation
   - Implement multi-sig for large amounts
   - Test threshold on testnets first
   - Never expose private keys in logs

5. Accounting integration:
   - Export reports to CSV/Excel
   - Integrate with accounting software
   - Track for tax purposes
   - Maintain audit trail

6. Cost optimization:
   - Always use SLOW mode for consolidation
   - Batch operations when possible
   - Only consolidate above threshold
   - Monitor gas prices

7. Advanced features:
   - Two-way rebalancing (not just consolidation)
   - Dynamic target balances based on usage
   - Predictive rebalancing based on patterns
   - Integration with payment flows
*/

runExample().catch(console.error);
